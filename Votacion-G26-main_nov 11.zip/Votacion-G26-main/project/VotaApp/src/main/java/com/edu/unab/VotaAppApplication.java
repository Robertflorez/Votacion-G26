package com.edu.unab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VotaAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(VotaAppApplication.class, args);
	}

}
